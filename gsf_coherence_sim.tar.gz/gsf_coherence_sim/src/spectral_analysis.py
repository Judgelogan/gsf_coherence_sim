"""
Spectral analysis utilities for UFTC‑SF simulation.

This module provides a function to compute the spectral radius (the
largest absolute eigenvalue) of a square matrix.  The spectral radius
serves as a simple global measure of coherence: larger values
indicate stronger overall coupling.
"""

import numpy as np

def spectral_radius(matrix: np.ndarray) -> float:
    """Compute the spectral radius of a matrix.

    Parameters
    ----------
    matrix : np.ndarray
        A square array whose spectral radius (max absolute eigenvalue) is desired.

    Returns
    -------
    float
        The largest absolute eigenvalue of the matrix.
    """
    eigenvalues = np.linalg.eigvals(matrix)
    return float(np.max(np.abs(eigenvalues)))