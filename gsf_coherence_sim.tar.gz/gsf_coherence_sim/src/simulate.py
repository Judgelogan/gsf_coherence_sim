"""
Run the UFTC‑SF coherence simulation.

This script applies the Forgiveness, Love and Grace operators to a
baseline connectivity matrix and computes the spectral radius at each
stage.  It writes intermediate matrices to CSV files and generates
plots showing the trajectory of the spectral radius and network
diagrams for each stage.

To execute the simulation from the command line, run:

    python src/simulate.py

The outputs will be saved in the `out/` directory relative to the
project root.
"""

import os
import numpy as np
from operators import apply_forgiveness, apply_love, apply_grace
from spectral_analysis import spectral_radius
from visualize import plot_spectral_trajectory, plot_network

def main() -> None:
    # Determine the project root (one level above this file’s directory)
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    out_matrices = os.path.join(project_root, 'out', 'matrices')
    out_plots = os.path.join(project_root, 'out', 'plots')
    os.makedirs(out_matrices, exist_ok=True)
    os.makedirs(out_plots, exist_ok=True)

    # Baseline connectivity matrix (March 12 turbulence)
    C_baseline = np.array([
        [1.0, 0.8, 0.3],
        [0.8, 1.0, 0.6],
        [0.3, 0.6, 1.0]
    ], dtype=float)

    radii = []
    labels = []

    # Baseline spectral radius
    radii.append(spectral_radius(C_baseline))
    labels.append('Baseline')

    # Stage 1: Forgiveness
    C_forgiveness = apply_forgiveness(C_baseline, beta=0.6, gamma=0.2, threshold=0.5)
    radii.append(spectral_radius(C_forgiveness))
    labels.append('Forgiveness')

    # Stage 2: Love
    C_love = apply_love(C_forgiveness)
    radii.append(spectral_radius(C_love))
    labels.append('Love')

    # Stage 3: Grace
    C_grace = apply_grace(C_love)
    radii.append(spectral_radius(C_grace))
    labels.append('Grace')

    # Save matrices to CSV
    np.savetxt(os.path.join(out_matrices, 'baseline.csv'), C_baseline, delimiter=',')
    np.savetxt(os.path.join(out_matrices, 'forgiveness.csv'), C_forgiveness, delimiter=',')
    np.savetxt(os.path.join(out_matrices, 'love.csv'), C_love, delimiter=',')
    np.savetxt(os.path.join(out_matrices, 'grace.csv'), C_grace, delimiter=',')

    # Plot spectral trajectory
    trajectory_path = os.path.join(out_plots, 'spectral_trajectory.png')
    plot_spectral_trajectory(radii, labels, trajectory_path)

    # Plot network diagrams
    plot_network(C_baseline, 'Baseline Connectivity', os.path.join(out_plots, 'network_baseline.png'))
    plot_network(C_forgiveness, 'After Forgiveness', os.path.join(out_plots, 'network_forgiveness.png'))
    plot_network(C_love, 'After Love', os.path.join(out_plots, 'network_love.png'))
    plot_network(C_grace, 'After Grace', os.path.join(out_plots, 'network_grace.png'))

    # Print spectral radii to the console for quick reference
    for label, rad in zip(labels, radii):
        print(f"{label} spectral radius: {rad:.4f}")

if __name__ == '__main__':
    main()