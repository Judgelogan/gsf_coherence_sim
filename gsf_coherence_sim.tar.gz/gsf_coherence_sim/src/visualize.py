"""
Plotting utilities for the UFTC‑SF coherence simulation.

This module contains functions to visualise the evolution of the
spectral radius across operator stages and to display connectivity
matrices as colour‑coded network graphs.
"""

import os
from typing import Iterable, List
import matplotlib.pyplot as plt
import numpy as np

def plot_spectral_trajectory(radii: Iterable[float], labels: Iterable[str], output_path: str) -> None:
    """Plot a line chart of spectral radii across stages.

    Parameters
    ----------
    radii : iterable of float
        Spectral radii computed at each stage.
    labels : iterable of str
        Labels for the x‑axis corresponding to each stage.
    output_path : str
        Path to save the resulting PNG image.
    """
    radii = list(radii)
    labels = list(labels)
    plt.figure(figsize=(6, 4))
    plt.plot(range(len(radii)), radii, marker='o', linestyle='-')
    plt.xticks(range(len(labels)), labels)
    plt.xlabel('Stage')
    plt.ylabel('Spectral Radius')
    plt.title('Global Coherence Spectral Radius Trajectory')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path)
    plt.close()

def plot_network(C: np.ndarray, title: str, output_path: str) -> None:
    """Plot a network diagram from a connectivity matrix without external graph libraries.

    Nodes are positioned on a circle.  Edges are colour‑coded based on their
    weight:

    - red for weights < 0.5
    - orange for weights between 0.5 and 0.75
    - green for weights > 0.75

    Parameters
    ----------
    C : np.ndarray
        Square connectivity matrix.
    title : str
        Title for the plot.
    output_path : str
        Path to save the resulting PNG image.
    """
    n = C.shape[0]
    # Compute positions on a unit circle
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
    x = np.cos(angles)
    y = np.sin(angles)

    # Create figure
    fig, ax = plt.subplots(figsize=(4, 4))

    # Draw edges for upper triangle
    for i in range(n):
        for j in range(i + 1, n):
            weight = float(C[i, j])
            # Determine colour based on weight
            if weight < 0.5:
                colour = 'red'
            elif weight <= 0.75:
                colour = 'orange'
            else:
                colour = 'green'
            ax.plot([x[i], x[j]], [y[i], y[j]], color=colour, linewidth=2, zorder=1)

    # Draw nodes and labels
    for i in range(n):
        ax.scatter(x[i], y[i], s=700, color='lightblue', edgecolors='black', zorder=2)
        ax.text(x[i], y[i], f'Node {i + 1}', horizontalalignment='center', verticalalignment='center',
                fontsize=10, fontweight='bold', zorder=3)

    ax.set_title(title)
    ax.set_aspect('equal')
    ax.axis('off')
    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path)
    plt.close()