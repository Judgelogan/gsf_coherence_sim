"""
Symbolic coherence operators for UFTC‑SF simulation.

This module defines the Forgiveness, Love and Grace operators.  Each
operator takes a connectivity matrix and returns a modified matrix
according to the rules described in Appendix G.7.
"""

import numpy as np

def apply_forgiveness(C: np.ndarray, beta: float = 0.6, gamma: float = 0.2, threshold: float = 0.5) -> np.ndarray:
    """Apply the forgiveness operator to a connectivity matrix.

    Parameters
    ----------
    C : np.ndarray
        Input connectivity matrix (assumed symmetric with 1s on the diagonal).
    beta : float, optional
        Scaling factor applied to elements above the threshold (default 0.6).
    gamma : float, optional
        Scaling factor applied to elements below or equal to the threshold (default 0.2).
    threshold : float, optional
        Threshold dividing "strong" and "weak" connections (default 0.5).

    Returns
    -------
    np.ndarray
        Modified connectivity matrix after applying forgiveness.
    """
    C = np.array(C, dtype=float)
    strong_mask = C > threshold
    weak_mask = ~strong_mask
    # Scale strong connections by beta and weak connections by gamma
    C[strong_mask] *= beta
    C[weak_mask] *= gamma
    return C

def apply_love(C: np.ndarray) -> np.ndarray:
    """Apply the love operator to a connectivity matrix.

    The love operator amplifies coherence with piecewise rules:

    - If C_ij > 0.75: saturate to 1.0
    - If 0.5 < C_ij ≤ 0.75: scale by 1.25
    - If 0 < C_ij ≤ 0.5: add 0.175

    Parameters
    ----------
    C : np.ndarray
        Input connectivity matrix.

    Returns
    -------
    np.ndarray
        Modified connectivity matrix after applying love.
    """
    C = np.array(C, dtype=float)
    high_mask = C > 0.75
    mid_mask = (C > 0.5) & (C <= 0.75)
    low_mask = (C > 0) & (C <= 0.5)
    # Saturate high values
    C[high_mask] = 1.0
    # Scale mid values
    C[mid_mask] *= 1.25
    # Add to low values
    C[low_mask] += 0.175
    return C

def apply_grace(C: np.ndarray) -> np.ndarray:
    """Apply the grace operator to a connectivity matrix.

    The grace operator uses a sigmoid function to perform a nonlinear
    transformation:

    G(C_ij) = 1 / (1 + exp(-5 * (C_ij - 0.5)))

    Parameters
    ----------
    C : np.ndarray
        Input connectivity matrix.

    Returns
    -------
    np.ndarray
        Modified connectivity matrix after applying grace.
    """
    C = np.array(C, dtype=float)
    return 1.0 / (1.0 + np.exp(-5.0 * (C - 0.5)))